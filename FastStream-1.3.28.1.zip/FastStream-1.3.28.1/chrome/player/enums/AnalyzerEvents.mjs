export const AnalyzerEvents = {
  MATCH: 'match',
  INTRO_MATCH: 'introMatch',
  OUTRO_MATCH: 'outroMatch',
};
