export const ReferenceTypes = {
  GRANDFATHERED: 0,
  ANALYZER: 1,
  SAVER: 2,
  MP4PLAYER: 3,
};
