export const ClickActions = {
  PLAY_PAUSE: 'playpause',
  FULLSCREEN: 'fullscreen',
  PIP: 'pip',
  HIDE_CONTROLS: 'hidecontrols',
  HIDE_PLAYER: 'hideplayer',
};
