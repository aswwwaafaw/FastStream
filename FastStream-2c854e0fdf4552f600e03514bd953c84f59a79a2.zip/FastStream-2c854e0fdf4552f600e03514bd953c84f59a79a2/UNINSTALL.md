# Uninstallation guide

To uninstall the extension, simply right click the icon and click "Remove from Chrome" (Chrome) or "Remove extension" (Firefox). Thats it!

## Before you leave

Please let us know if you are uninstalling because of a bug. Report all bugs to the [issue tracker](https://github.com/Andrews54757/FastStream/issues). New bugs are usually addressed in 1-2 days.

#### Please report any bugs you notice! We won't know about it otherwise!