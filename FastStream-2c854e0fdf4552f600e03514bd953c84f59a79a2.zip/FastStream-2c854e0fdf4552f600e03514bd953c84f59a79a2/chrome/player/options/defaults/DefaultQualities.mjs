export const DefaultQualities = {
  'AUTO': 'Auto',
  '144p': '144p',
  '480p': '480p',
  '720p': '720p',
  '1080p': '1080p',
  '1440p': '1440p',
  '2160p': '2160p',
  '4320p': '4320p',
};
