export const DaltonizerTypes = {
  NONE: 'none',
  PROTANOMALY: 'protanomaly',
  DEUTERANOMALY: 'deuteranomaly',
  TRITANOMALY: 'tritanomaly',
};
