export const YoutubeClients = {
  WEB: 'WEB',
  ANDROID: 'ANDROID',
  IOS: 'IOS',
  TV_EMBEDDED: 'TV_EMBEDDED',
};
