export const PlayerModes = {
  AUTO: 'auto',
  DIRECT: 'direct',
  ACCELERATED_MP4: 'accelerated_mp4',
  ACCELERATED_HLS: 'accelerated_hls',
  ACCELERATED_DASH: 'accelerated_dash',
  ACCELERATED_YT: 'accelerated_yt',
  IFRAME: 'iframe',
};
