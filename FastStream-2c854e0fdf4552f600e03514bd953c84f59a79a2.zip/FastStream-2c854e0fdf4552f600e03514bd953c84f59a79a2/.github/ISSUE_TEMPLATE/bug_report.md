---
name: Bug report
about: Create a report to help us fix issues
title: "[BUG]"
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Version**
FastStream version. You can get the version by opening the player, it will display "Welcome to FastStream Vx.x.x"

**Platform**
The browser you are using Chrome/Firefox/etc..

**Steps to Reproduce**
Please tell us how to reproduce the issue. A URL to a specific video is encouraged.
